CREATE DATABASE  IF NOT EXISTS `pharma_db`;
use `pharma_db`;
CREATE TABLE `pharmacy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `price` double(4,2) DEFAULT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

insert into pharmacy values(
1,'paracetamol','tablet',50.00,'abc','2020-02-02');

-- drop table pharmacy;
select * from pharmacy;

CREATE TABLE `login` (
`id` int(11) NOT NULL,
`username` varchar(45) NOT NULL,
`password` varchar(45) NOT NULL,primary key(`id`)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

INSERT INTO `login` VALUES(1,'neethi123','user100');
INSERT INTO `login` VALUES(2,'neethi122','user101');
drop table login;
select * from login;